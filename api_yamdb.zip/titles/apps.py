from django.apps import AppConfig


class TitlesConfig(AppConfig):
    name = 'titles'
