pytest_plugins = [
    'tests.fixtures.fixture_user',
    # 'tests.fixtures.fixture_data',
]
